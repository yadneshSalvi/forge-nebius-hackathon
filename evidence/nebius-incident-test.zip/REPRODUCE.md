# Forge incident regression test

Post-final diagnostic · initial-scene paired reset

Total scene intervention effect in the gantry simulation, including instrumented policy observations. Excluded from registered statistics, nomination and training. No mid-episode fork or perception-only claim.

Install requirements.txt in the bound Python 3.11 runtime, then from any working directory:

    python /absolute/bundle/scripts/incident_reproduce.py --bundle /absolute/bundle --verify
    python /absolute/bundle/scripts/incident_reproduce.py --bundle /absolute/bundle --rerun
    python /absolute/bundle/scripts/incident_reproduce.py --bundle /absolute/bundle --rerun --checkpoint /absolute/compatible.json

--rerun executes the anchored original/intervention pair. Add --all-pairs for the entire frozen schedule. Alternate checkpoints are data-only JSON, validated against the exact task/controller/observations/actions/normalization/tensor schema. Their outcomes form a new diagnostic, never expected to reproduce the original policy. No credentials, server or network are used. --output writes a JSON report. All attempts are retained. The camera is an inspection view; this policy receives privileged state. OS/architecture are reported separately from pinned dependency compatibility.
